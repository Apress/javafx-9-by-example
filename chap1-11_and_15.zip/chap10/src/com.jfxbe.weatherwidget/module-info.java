module com.jfxbe.weatherwidget {
  requires javafx.web;
  requires jdk.jsobject;
  requires jdk.incubator.httpclient;

  exports com.jfxbe.weatherwidget;
}

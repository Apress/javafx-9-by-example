module com.jfxbe.html5content {
  requires javafx.web;
  requires jdk.jsobject;

  exports com.jfxbe.html5content;
}

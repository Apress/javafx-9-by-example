rm -rf mlib
rm -rf classpath
rm -rf mods

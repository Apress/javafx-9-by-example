./clean
./compile
./run




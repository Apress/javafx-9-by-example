module com.jfxbe.helloworld {
  requires javafx.base;
  requires javafx.graphics;
  requires javafx.controls;
  exports com.jfxbe.helloworld;
}

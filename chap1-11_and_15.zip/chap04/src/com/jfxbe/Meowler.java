package com.jfxbe;

public interface Meowler {
    default void meow() {
        System.out.println("MeeeeOww!");
    }
}

./clean
./build
./package

java -cp mlib/chap04.jar com.jfxbe.AggregateOperations
java -cp mlib/chap04.jar com.jfxbe.BindingExpressions
java -cp mlib/chap04.jar com.jfxbe.FormValidation
java -cp mlib/chap04.jar com.jfxbe.FunctionalInterfaces
java -cp mlib/chap04.jar com.jfxbe.Lambdas
java -cp mlib/chap04.jar com.jfxbe.Mixins

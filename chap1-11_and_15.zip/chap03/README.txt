# Windows
compile


# Mac OS or Linux
# compiles the code
./compile


# run an individual example
java -cp classpath com.jfxbe.ChangingTextFonts
java -cp classpath com.jfxbe.DrawingLines
java -cp classpath com.jfxbe.DrawingShapes
java -cp classpath com.jfxbe.DrawingText
java -cp classpath com.jfxbe.LinesPixelPrecision
java -cp classpath com.jfxbe.PaintingColors

module com.jfxbe.helloworld {
  requires javafx.base;
  requires javafx.graphics;
  requires javafx.controls;
  requires jdk.httpserver;
  exports com.jfxbe.helloworld;
}
